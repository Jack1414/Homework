﻿using System;

namespace Task5
{
    class Program
    {
        static void Main(string[] args)
        {
           /* Да се модифицира примерната програма, така че да изписва
            различно поздравление, например "Good day!".*/
            Console.WriteLine("Good day!");
        }
    }
}
