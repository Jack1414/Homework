﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Да се намери описанието на класа System.Console в стандартната .NET
            API документация (MSDN Library).*/
            Console.WriteLine("Done!");
        }
    }
}
