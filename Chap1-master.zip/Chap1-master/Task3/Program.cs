﻿using System;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Да се намери описанието на метода System.Console.WriteLine(…) с
            различните негови възможни параметри в MSDN Library.*/

            Console.WriteLine("Ready");
        }
    }
}
