﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Да се компилира и изпълни примерната програма от примерите в
            тази глава през командния ред и с помощта на Visual Studio.*/
            Console.WriteLine("Will be done in next examples!");
        }
    }
}
