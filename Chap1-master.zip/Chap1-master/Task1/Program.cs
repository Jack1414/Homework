﻿using System;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Запознайте се с Microsoft Visual Studio и Microsoft Developer Network
            (MSDN) Library Documentation. Инсталирайте си Visual Studio.*/
            Console.WriteLine("Done!");
        }
    }
}
