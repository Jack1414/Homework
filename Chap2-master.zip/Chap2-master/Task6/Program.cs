﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task6
{
    class Program
    {
        static void Main(string[] args)
        {
            //Декларирайте променлива isMale от тип bool и присвоете стойност на последната в зависимост от вашия пол.

            bool isMale = true;
            Console.WriteLine(isMale);
        }
    }
}
