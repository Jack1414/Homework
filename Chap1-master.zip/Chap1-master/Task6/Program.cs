﻿using System;

namespace Task6
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Напишете програма, която изписва вашето име и фамилия на
            конзолата.*/
            Console.WriteLine("Vasil Dachev!");
        }
    }
}
