﻿using System;

namespace Task7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1 101 1001");
        }
    }
}
