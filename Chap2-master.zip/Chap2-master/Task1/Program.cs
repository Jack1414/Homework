﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Декларирайте няколко променливи, като изберете за всяка една найподходящия от типовете
             * sbyte, byte, short, ushort, int, uint, long и ulong, за да им присвоите следните стойности: 
             * 52130, -115, 4825932, 97, -10000, 20000; 224; 970700000; 112; -44; -1000000; 1990; 123456789123456789. */
            sbyte A = -115;
            sbyte B = -44;
            byte C = 97;
            byte D = 224;
            short E = 20000;
            ushort F = 52130;
            short G = 1190;
            int H = 970700000;
            int I = 4825932;
            ulong J = 12345789123456789;
        }
    }
}
