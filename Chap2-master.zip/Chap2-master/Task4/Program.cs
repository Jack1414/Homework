﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Инициализирайте променлива от тип int със стойност 256 в шестна-
            //десетичен формат(256 е 100 в бройна система с основа 16).
            int hex = 72;
            Console.WriteLine("In HEX : {0:X}", hex);
        }
    }
}
