﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task12
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Напишете булев израз, който проверява дали битът на позиция p на
            цялото число v има стойност 1. Пример v=5, p =1 -> false.*/

        }
    }
}
