﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task10
{
    class Program
    {
        static void Main(string[] args)
        {
            //Напишете програма, която принтира фигура във формата на сърце със знака "o".

            Console.WriteLine("    oooo   oooo ");
            Console.WriteLine("   oooooo oooooo ");
            Console.WriteLine("    ooooooooooo ");
            Console.WriteLine("      ooooooo  ");
            Console.WriteLine("        ooo ");
        }
    }
}
